
package modelo;


public enum nivelUso {
    BAJA,
    MEDIA,
    ALTA
    
}
