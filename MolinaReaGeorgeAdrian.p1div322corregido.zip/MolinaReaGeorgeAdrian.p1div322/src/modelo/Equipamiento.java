
package modelo;


public abstract class Equipamiento{
    protected String nombre;
    protected String sector;
    protected nivelUso niveluso;

    public Equipamiento(String nombre, String sector, nivelUso niveluso) {
        this.nombre = nombre;
        this.sector = sector;
        this.niveluso = niveluso;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
            }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        Equipamiento otro = (Equipamiento) obj; 
        return nombre.equals(otro.nombre) && sector.equals(otro.sector);
    }
    
    public void prepararUso(){
    };

    public nivelUso getNiveluso() {
        return niveluso;
    }
    
    
    
    
}