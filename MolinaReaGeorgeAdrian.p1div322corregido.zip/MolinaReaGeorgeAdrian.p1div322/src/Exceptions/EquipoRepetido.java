
package Exceptions;


public class EquipoRepetido extends Exception {

    public EquipoRepetido(String message) {
        super(message);
    }
    
    
}
