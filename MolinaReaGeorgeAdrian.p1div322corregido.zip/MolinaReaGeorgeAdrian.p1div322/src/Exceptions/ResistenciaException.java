
package Exceptions;

public class ResistenciaException extends Exception{

    public ResistenciaException(String message) {
        super(message);
    }
    
    
}
